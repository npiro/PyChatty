

# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def read_line_from_file(line_num):
    folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
    client_file = codecs.open(folder + '04_clientMessagesFiltered.txt', 'r', 'utf-8')
    agent_file = codecs.open(folder + '04_agentMessagesFiltered.txt', 'r', 'utf-8')
    
    for i, line in enumerate(client_file):
        if i == line_num:
            Input = line
    
    for i, line in enumerate(agent_file):
        if i == line_num:
            Output = line
    return (Input, Output)


"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle



# load it again


with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)



# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def read_line_from_file(line_num):
    folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
    client_file = codecs.open(folder + '04_clientMessagesFiltered.txt', 'r', 'utf-8')
    agent_file = codecs.open(folder + '04_agentMessagesFiltered.txt', 'r', 'utf-8')
    
    for i, line in enumerate(client_file):
        if i == line_num:
            Input = line
    
    for i, line in enumerate(agent_file):
        if i == line_num:
            Output = line
    return (Input, Output)


"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle



# load it again


with codecs.open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)



# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def read_line_from_file(line_num):
    folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
    client_file = codecs.open(folder + '04_clientMessagesFiltered.txt', 'r', 'utf-8')
    agent_file = codecs.open(folder + '04_agentMessagesFiltered.txt', 'r', 'utf-8')
    
    for i, line in enumerate(client_file):
        if i == line_num:
            Input = line
    
    for i, line in enumerate(agent_file):
        if i == line_num:
            Output = line
    return (Input, Output)


"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle



# load it again





# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def read_line_from_file(line_num):
    folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
    client_file = codecs.open(folder + '04_clientMessagesFiltered.txt', 'r', 'utf-8')
    agent_file = codecs.open(folder + '04_agentMessagesFiltered.txt', 'r', 'utf-8')
    
    for i, line in enumerate(client_file):
        if i == line_num:
            Input = line
    
    for i, line in enumerate(agent_file):
        if i == line_num:
            Output = line
    return (Input, Output)


with codecs.open(folder + 'kdtree.pkl', 'rb','utf-8') as fid:
    tree = pickle.load(fid)

while True:
    query = input('<Chatty 1.0> ')
    
    dist, ind = tree.query(get_sentence_vector(query), k=1)
    Input, Output = outread_line_from_file(line_num)
    print(Input)
    print(Output)

import pickle
# save the classifier
with open(folder + 'kdtree.pkl', 'wb') as fid:
    pickle.dump(tree, fid)


with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


while True:
    query = input('<Chatty 1.0> ')
    
    dist, ind = tree.query(get_sentence_vector(query), k=1)
    Input, Output = outread_line_from_file(line_num)
    print(Input)
    print(Output)

with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))

while True:
    query = input('<Chatty 1.0> ')
    
    dist, ind = tree.query(get_sentence_vector(query), k=1)
    Input, Output = outread_line_from_file(line_num)
    print(Input)
    print(Output)

How are you?

with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))

while True:
    query = input('<Chatty 1.0> ')
    
    dist, ind = tree.query(get_sentence_vector(query), k=1)
    Input, Output = outread_line_from_file(line_num)
    print(Input)
    print(Output)

with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))

while True:
    query = input('<Chatty 1.0> ')
    
    dist, ind = tree.query(get_sentence_vector(query), k=1)
    Input, Output = outread_line_from_file(line_num)
    print(Input)
    print(Output)

with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))

while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    dist, ind = tree.query(vect, k=1)
    Input, Output = read_line_from_file(ind)
    print(Input)
    print(Output)

debugfile('/Users/piromast/Dropbox/S2DS - M&S/Code/Nico/Word2vec/ChatBotV1.py', wdir='/Users/piromast/Dropbox/S2DS - M&S/Code/Nico/Word2vec')
"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle





with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))


# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.lower().strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def read_line_from_file(line_num):
    folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
    client_file = codecs.open(folder + '04_clientMessagesFiltered.txt', 'r', 'utf-8')
    agent_file = codecs.open(folder + '04_agentMessagesFiltered.txt', 'r', 'utf-8')
    
    for i, line in enumerate(client_file):
        if i == line_num:
            Input = line
    
    for i, line in enumerate(agent_file):
        if i == line_num:
            Output = line
    return (Input, Output)


while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect, k=1)
    Input, Output = read_line_from_file(ind)
    print(Input)
    print(Output)

"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle





with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))


# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.lower().strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def read_line_from_file(line_num):
    folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
    client_file = codecs.open(folder + '03_clientMessagesMatch04.txt.txt', 'r', 'utf-8')
    agent_file = codecs.open(folder + '03_agentMessagesMatch04.txt', 'r', 'utf-8')
    
    for i, line in enumerate(client_file):
        if i == line_num:
            Input = line
    
    for i, line in enumerate(agent_file):
        if i == line_num:
            Output = line
    return (Input, Output)


while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect, k=1)
    Input, Output = read_line_from_file(ind)
    print(Input)
    print(Output)

runfile('/Users/piromast/Dropbox/S2DS - M&S/Code/Nico/Word2vec/ChatBotV1.py', wdir='/Users/piromast/Dropbox/S2DS - M&S/Code/Nico/Word2vec')
from sklearn.neighbors import KDTree
tree = KDTree(client_sentences)

from sklearn.neighbors import KDTree
tree = KDTree(client_sentences)

import os.path
import gensim
import codecs
import numpy as np
import warnings
folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))

clientFileName = os.path.join(folder, '04_clientMessagesFiltered.txt')

file = codecs.open(clientFileName, 'r', 'utf-8')

#sentence_vects = np.empty((0, 100))
sentence_vects = []

with warnings.catch_warnings():
    warnings.simplefilter("ignore", category=RuntimeWarning)
    for sentence in file:
        
        vect = np.mean([model[w].T for w in sentence.strip().split() if w in model], axis = 0) # Calculate mean word vector for each sentence
        
        #sentence_vects = np.vstack((sentence_vects,vect))
        #sentence_vects = np.append(sentence_vects, [vect.T], axis = 0) # Calculate mean word vector for each sentence
        sentence_vects.append([vect]) 



client_sentences = np.zeros((len(sentence_vects), 100))
for i, sentence in enumerate(sentence_vects):
    client_sentences[i, :] = np.array(sentence)


def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect


from sklearn.neighbors import KDTree
tree = KDTree(client_sentences)

dist, ind = tree.query(sentence_vects[0], k=3) 

import pickle
# save the classifier
with open(folder + 'kdtree.pkl', 'wb') as fid:
    pickle.dump(tree, fid)


"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'


with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)



model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))


# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.lower().strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def read_line_from_file(line_num):
    folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
    client_file = codecs.open(folder + '03_clientMessagesMatch04.txt', 'r', 'utf-8')
    agent_file = codecs.open(folder + '03_agentMessagesMatch04.txt', 'r', 'utf-8')
    
    for i, line in enumerate(client_file):
        if i == line_num:
            Input = line
    
    for i, line in enumerate(agent_file):
        if i == line_num:
            Output = line
    return (Input, Output)


while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect, k=1)
    Input, Output = read_line_from_file(ind)
    print('input:'+Input)
    print(Output)




vect

while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(-1,1), k=1)
    Input, Output = read_line_from_file(ind)
    print('input:'+Input)
    print(Output)

while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(1,-1), k=1)
    Input, Output = read_line_from_file(ind)
    print('input:'+Input)
    print(Output)

query = 'i want to reschedule my delivery date'
dist, ind = tree.query(get_sentence_vector(query), k=1)
query = 'i want to reschedule my delivery date'
dist, ind = tree.query(get_sentence_vector(query), k=1)
print(dist)
query = 'i want to reschedule my delivery date'
dist, ind = tree.query(get_sentence_vector(query).reshape(1,-1), k=1)
print(dist)
from sklearn.neighbors import KDTree
tree = KDTree(client_sentences)

with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


del(tree)

with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


query = 'i want to reschedule my delivery date'
dist, ind = tree.query(get_sentence_vector(query).reshape(1,-1), k=1)
print(dist)
with codecs.open(folder + '03_agentMessagesMatch04.txt', 'r', 'utf-8') as f:
    df = pd.DataFrame([lines for lines in f])

with open(folder + 'agentMessagesDF.pkl', 'wb') as fid:
    pickle.dump(df, fid)


import os.path
import gensim
import codecs
import numpy as np
import pandas as pd
import warnings
import pickle
with codecs.open(folder + '03_agentMessagesMatch04.txt', 'r', 'utf-8') as f:
    df = pd.DataFrame([lines for lines in f])

with open(folder + 'agentMessagesDF.pkl', 'wb') as fid:
    pickle.dump(df, fid)


df[0]
df.iloc[0]

with codecs.open(folder + '03_agentMessagesMatch04.txt', 'r', 'utf-8') as f:
    df = pd.DataFrame({'Msgs':[lines for lines in f]})

with open(folder + 'agentMessagesDF.pkl', 'wb') as fid:
    pickle.dump(df, fid)


df.Msgs.iloc[0]

with open(folder + 'agentMessagesDF.pkl', 'rb') as fid:
    df = pickle.load(fid)

# In [4]:
# Query as follows
df.Msgs.iloc[0].strip()
fullAgentMessagesFile = folder + '03_agentMessagesMatch04.txt'
fullClientMessagesFile = folder + '03_clientMessagesMatch04.txt'
with codecs.open(fullAgentMessagesFile, 'r', 'utf-8') as fA, codecs.open(fullClientMessagesFile, 'r', 'utf-8') as fC:
    df = pd.DataFrame({'Agent':[lines for lines in fA], 'Client':[lines for lines in fC]})

with open(folder + 'MessagesDF.pkl', 'wb') as fid:
    pickle.dump(df, fid)


with open(folder + 'MessagesDF.pkl', 'rb') as fid:
    df = pickle.load(fid)

# In [4]:
# Query as follows
df.Client.iloc[0].strip()

"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'

# Retrieve client tree
with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


# Retrieve agent data frame:
with open(folder + 'agentMessagesDF.pkl', 'rb') as fid:
    df = pickle.load(fid)


# Retrieve word2vec model
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))


# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.lower().strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def get_message(line_num):
    
    ClientText = df.Client.iloc[line_num].strip()
    AgentText = df.Agent.iloc[line_num].strip()
    
    return (ClientText, AgentText)



while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(1,-1), k=1)
    Input, Output = get_message(ind)
    print('input:'+Input)
    print(Output)

"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'

# Retrieve client tree
with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


# Retrieve agent data frame:
with open(folder + 'agentMessagesDF.pkl', 'rb') as fid:
    df = pickle.load(fid)


# Retrieve word2vec model
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))


# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.lower().strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def get_message(line_num):
    
    ClientText = df.Client.iloc[line_num].strip()
    AgentText = df.Agent.iloc[line_num].strip()
    
    return (ClientText, AgentText)



del(df)

"""
Created on Mon Aug  8 19:27:30 2016

@author: piromast
"""

import os.path
import gensim
import codecs
import numpy as np
import pickle


folder = '/Users/piromast/Dropbox/S2DS - M&S/Data/'
ModelFileName ='clientW2V_BothSeperate'

# Retrieve client tree
with open(folder + 'kdtree.pkl', 'rb') as fid:
    tree = pickle.load(fid)


# Retrieve messages data frame:
with open(folder + 'MessagesDF.pkl', 'rb') as fid:
    df = pickle.load(fid)


# Retrieve word2vec model
model = gensim.models.Word2Vec.load(os.path.join(folder,ModelFileName))


# Define a function to get the vector for a user sentence 
def get_sentence_vector(sentence):
    sentence_matrix = np.array([model[w].T for w in sentence.lower().strip().split() if w in model])
    sentence_vect = np.mean(sentence_matrix, axis=0)
    return sentence_vect



def get_message(line_num):
    
    ClientText = df.Client.iloc[line_num].strip()
    AgentText = df.Agent.iloc[line_num].strip()
    
    return (ClientText, AgentText)



while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(1,-1), k=1)
    Input, Output = get_message(ind)
    print('input:'+Input)
    print(Output)

df.Client.iloc(1)

ind

while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(1,-1), k=1)
    Input, Output = get_message(ind[0][0])
    print('input:'+Input)
    print(Output)

while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(1,-1), k=1)
    Input, Output = get_message(ind[0][0])
    print('input:'+Input)
    print(Output)

while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(1,-1), k=1)
    try:
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        pass

while True:
    query = input('<Chatty 1.0> ')
    
    vect = get_sentence_vector(query)
    
    dist, ind = tree.query(vect.reshape(1,-1), k=1)
    try:
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        pass

while True:
    query = input('<Chatty 1.0> ')
    try:
        vect = get_sentence_vector(query)
        
        dist, ind = tree.query(vect.reshape(1,-1), k=1)
        
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        pass

while True:
    query = input('<Chatty 1.0> ')
    try:
        vect = get_sentence_vector(query)
        
        dist, ind = tree.query(vect.reshape(1,-1), k=1)
        
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        print("I don't understand. Please be more clear! ")

while True:
    query = input('<Chatty 1.0> ')
    try:
        vect = get_sentence_vector(query)
        
        dist, ind = tree.query(vect.reshape(1,-1), k=1)
        
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        print("I don't understand. Please be more clear! ")

while True:
    query = input('<Chatty 1.0> ')
    if query == quit:
        break
    try:
        vect = get_sentence_vector(query)
        
        dist, ind = tree.query(vect.reshape(1,-1), k=1)
        
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        print("I don't understand. Please be more clear! ")

while True:
    query = input('<Chatty 1.0> ')
    if query.strip() == quit:
        break
    try:
        vect = get_sentence_vector(query)
        
        dist, ind = tree.query(vect.reshape(1,-1), k=1)
        
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        print("I don't understand. Please be more clear! ")

while True:
    query = input('<Chatty 1.0> ')
    if query == 'quit':
        break
    try:
        vect = get_sentence_vector(query)
        
        dist, ind = tree.query(vect.reshape(1,-1), k=1)
        
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        print("I don't understand. Please be more clear! ")

while True:
    query = input('<Chatty 1.0> ')
    if query == 'quit':
        break
    try:
        vect = get_sentence_vector(query)
        
        dist, ind = tree.query(vect.reshape(1,-1), k=1)
        
        Input, Output = get_message(ind[0][0])
        print('input:'+Input)
        print(Output)
    except:
        print("I don't understand. Please be more clear! ")
